# orbital-patterns
![This is an image](https://images-ext-2.discordapp.net/external/reeKlQI6RiU9At2H5C-73ryCnpLqL4ru7shOThJFGdw/https/repository-images.githubusercontent.com/445509211/95c2a5b3-2bb4-4aad-8acf-1209bf9700ec)

- Click to spawn planets
- Press "S" to capture screenshot. Image will be saved in the same directory as the script.
- Press "Q" to exit.
- Press "A" to get a view of the axes and a line joining the origin and your cursor.
